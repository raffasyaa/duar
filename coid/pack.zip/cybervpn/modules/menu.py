from cybervpn import *
from telethon import events, Button
import requests

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    sender = await event.get_sender()
    user_id = str(event.sender_id)
    sender_username = sender.username

    if check_user_registration(user_id):
        try:
            s = 'bash /usr/bin/menu-reseller'
            m = subprocess.check_output(s, shell=True).decode("utf-8")
            o = 'bash /usr/bin/menu-admin'
            z = subprocess.check_output(o, shell=True).decode("utf-8")
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("𝗦𝗦𝗛", "ssh"),
                    Button.inline("𝗩𝗠𝗘𝗦𝗦", "vmess-member")],
                    [Button.inline("𝗩𝗟𝗘𝗦𝗦", "vless-member"),
                    Button.inline("𝗧𝗥𝗢𝗝𝗔𝗡", "trojan-member")],
                    [Button.inline("🏧TopUp Saldo🏧", "topup")],
                ]

                member_msg = f"""
**{m}**
```👤Username : @{sender_username}
👤User ID  : {user_id}
🏧Saldo Ku : Rp{saldo_aji}```
```📝 15 Hari : Rp 5.000/Bulan
📝 30 Hari : Rp 10.000/Bulan
📝 60 Hari : Rp 15.000/Bulan
📝 90 Hari : Rp 25.000/Bulan```
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
               [Button.inline(" 𝗦𝗦𝗛 ","ssh"),
Button.inline(" 𝗩𝗠𝗘𝗦𝗦 ","vmess")],
[Button.inline(" 𝗧𝗥𝗢𝗝𝗔𝗡 ","trojan"),
Button.inline(" 𝗩𝗟𝗘𝗦𝗦 ","vless")],
[Button.inline(" 𝗙𝗘𝗔𝗧𝗨𝗥𝗘 𝗠𝗔𝗡𝗔𝗚𝗘 ","setting")]]	

                admin_msg = f"""
{z}
```🏧SISA SALDO KU : Rp {saldo_aji}
📝TOTAL MEMBER  : {get_user_count()}```
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'```Anda belum terdaftar, silahkan registrasi```',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

