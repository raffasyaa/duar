from cybervpn import *
import subprocess
import datetime as DT
import sys
from telethon.sync import TelegramClient
import sqlite3

@bot.on(events.CallbackQuery(data=b'create-ssh-member'))
async def create_ssh(event):
    user_id = str(event.sender_id)

    async def create_ssh_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**➣ Username :**')
            user_msg = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = (await user_msg).raw_text
        
        async with bot.conversation(chat) as pw_conv:
            await event.respond("**➣ Password :**")
            pw_msg = pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            password = (await pw_msg).raw_text
        
        async with bot.conversation(chat) as exp_conv:
            await event.respond("**➣ Choose Expiry Day**", buttons=[
                [Button.inline("15 Hari", "basic")],
                [Button.inline("30 Hari", "premium")],
                [Button.inline("60 Hari", "pro")]
            ])
  exp_msg = await bot.wait_for(events.CallbackQuery, from_users=sender.id)
        account_type = exp_msg.data.decode("ascii")  # Jenis akun (basic, premium, pro)

        # Panggil fungsi untuk memproses saldo pengguna
        try:
            await process_user_balance_ssh(event, user_id, account_type)
        except Exception as e:
            await event.respond(f"**Terjadi kesalahan saat memproses saldo: {e}**")
            return

        # Tentukan jumlah hari sesuai tipe akun
        days_mapping = {
            "basic": 15,
            "premium": 30,
            "pro": 60
        }
        expiry_days = days_mapping.get(account_type, 15)

        # Eksekusi perintah useradd dan konfigurasi akun
        cmd = f'useradd -e `date -d "{expiry_days} days" +"%Y-%m-%d"` -s /bin/false -M {username} && echo "{password}\n{password}" | passwd {username}'
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**↻ Gagal membuat akun. Username mungkin sudah ada.**")
        else:
            # Hitung tanggal kedaluwarsa
            today = DT.date.today()
            expiry_date = today + DT.timedelta(days=expiry_days)
            msg = f"""
__Accounts Created Successfully__ 
**×━━━━━━━━━━━━━━━━━━━━━×**
**🔰Host/IP:** `{DOMAIN}`
**🔰Username:** `{user.strip()}`
**🔰Password:** `{pw.strip()}`
**×━━━━━━━━━━━━━━━━━━━━━×**
**🌀OpenSSH:** `22`
**🌀SSL/TLS:** `445`, `777`, `443`
**🌀Ssh Udp:** `1-65535`
**🌀Ssh Ohp:** `8181`
**🌀Dropbear Ohp:** `8282`
**🌀OpenVpn Ohp:** `8383`
**🌀Dropbear:** `109`,`143`
**🌀WS SSL:** `443`
**🌀WS HTTP:** `80`
**🌀Squid:** `8080`, `3128`
**🌀UDPGW :** `7100-7300`
**×━━━━━━━━━━━━━━━━━━━━━×**
**🍀Payload Ssh Ws🍀**
`GET / HTTP/1.1 [crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**×━━━━━━━━━━━━━━━━━━━━━×**
**🍀File OpenVPN🍀**
__{DOMAIN}:89/udp.ovpn__
__{DOMAIN}:89/ssl.ovpn__
__{DOMAIN}:89/tcp.ovpn__
**×━━━━━━━━━━━━━━━━━━━━━×**
**🗓Expiry:** `{later}`
**×━━━━━━━━━━━━━━━━━━━━━×**
"""
            await event.respond(msg)
    
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await create_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak.!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')

