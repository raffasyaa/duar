import requests
from cybervpn import *

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_member_manager(event):
        inline = [
            [Button.inline("Create SSH", "add-ssh"),
            Button.inline("Renew SSH", "renew-ssh")],
            [Button.inline("Trial SSH", "trial-ssh")],
            [Button.inline("🔙Kembali", "menu")],
]
        
        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**🔰SSH OVPN MENU**
__- OpenVpn Websocket__
__- Ssh Udp Custom__
__- Ssh Websocket__

**🔰DETAIL PORT**
__- 443,80,143,109,8080__
__- 8181,8282,22,3128__
__- And Etc__

**🔰SERVER INFO**
__- Domain: {DOMAIN}__
__- Region: {z["country"]}__
``` 💵Harga : Rp5.300/Bulan```
"""
        await event.edit(msg, buttons=inline)

    async def ssh_admin_manager(event):
        inline = [
[Button.inline(" Trial ","trial-ssh"),
Button.inline(" Create ","create-ssh")],
[Button.inline(" Delete ","delete-ssh"),
Button.inline(" Cek Login ","login-ssh")],
[Button.inline(" Member ","show-ssh"),
Button.inline(" Renew ","renew-ssh")],
[Button.inline("‹ Back Menu ›","menu")]]
        
        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**✅SSH OVPN MENU**
__- OpenVpn Websocket__
__- Ssh Udp Custom__
__- Ssh Websocket__

**✅DETAIL PORT**
__- 443,80,143,109,8080__
__- 8181,8282,22,3128__
__- And Etc__

**✅SERVER INFO**
__- Domain: {DOMAIN}__
__- Region: {z["country"]}__
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await ssh_admin_manager(event)
        else:
            await ssh_member_manager(event)
    except Exception as e:
        print(f'Error: {e}')

