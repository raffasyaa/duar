import requests
from cybervpn import *

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_member_manager(event):
        inline = [
            [Button.inline("Create SSH", "create-ssh-member"),
            Button.inline("Renew SSH", "renew-ssh-member")],
            [Button.inline("Trial SSH", "trial-ssh-member")],
            [Button.inline("🔙Kembali", "menu")],
]
        
        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**SSH/OpenVPN Menu**
- SSH
- SSH SSL
- SSH WS
- SSH WS-SSL
- SSH UDP
- SlowDNS
- OpenVPN
- BadVPN UDPgw
- HTTP Proxy

**Rules:**
- Max 2 Login
- Max 3x Peringatan (Ganti Password)
- Peringatan 4x Banned

**Harga:**
- Rp 5.000 / 15 Hari
- Rp 10.000 / 30 Hari
- Rp 15.000 / 60 Hari
"""
        await event.edit(msg, buttons=inline)

    async def ssh_admin_manager(event):
        inline = [
[Button.inline(" Trial ","trial-ssh"),
Button.inline(" Create ","create-ssh")],
[Button.inline(" Delete ","delete-ssh"),
Button.inline(" Cek Login ","login-ssh")],
[Button.inline(" Member ","show-ssh"),
Button.inline(" Renew ","renew-ssh")],
[Button.inline("‹ Back Menu ›","menu")]]
        
        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**SSH/OpenVPN Menu**
- SSH
- SSH SSL
- SSH WS
- SSH WS-SSL
- SSH UDP
- SlowDNS
- OpenVPN
- BadVPN UDPgw
- HTTP Proxy

**Rules:**
- Max 2 Login
- Max 3x Peringatan (Ganti Password)
- Peringatan 4x Banned
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await ssh_admin_manager(event)
        else:
            await ssh_member_manager(event)
    except Exception as e:
        print(f'Error: {e}')

