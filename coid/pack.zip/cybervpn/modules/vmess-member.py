from cybervpn import *
import subprocess
import json
import re
import base64
import datetime as DT
import requests
import time

# ... (kode lainnya)

@bot.on(events.CallbackQuery(data=b'create-vmess-member'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username :**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text


        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 30 Hari ", "30")]
            ])
            exp = (await exp_conv.wait_event(events.CallbackQuery)).data.decode("ascii")

        await process_user_balance_vmess(event, user_id)

        cmd = f'printf "%s\n" "{user}" "{exp}" | add-vmess'
        
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        msg = f"""
__Accounts Created Suuccessfuly__
**×━━━━━━━━━━━━━━━━━━━━━×**
    Xray/Vmess Accounts
**×━━━━━━━━━━━━━━━━━━━━━×**
🌀Remarks     : {z["ps"]}
🌀Domain      : {z["add"]}
🌀Port TLS    : 8443
🌀Port HTTP   : 8880
🌀User ID     : {z["id"]}
🌀Alter ID    : 0
🌀Security    : auto
🌀Network     : ws
🌀Path        : /v2ray
**×━━━━━━━━━━━━━━━━━━━━━×**
🍀Link TLS  : 
`{b[0].strip("'").replace(" ","")}`
**×━━━━━━━━━━━━━━━━━━━━━×**
🍀Link None TLS : 
`{b[1].strip("'").replace(" ","")}`
**×━━━━━━━━━━━━━━━━━━━━━×**
**✅Format OpenClash✅**
__{z["add"]}:89/vmess-{z["ps"]}.txt__
**📆Expiry      : {later}**
        """
        await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await create_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess-member'))
async def trial_vmess(event):
    async def trial_vmess_(event):

        # output cmd
        cmd = f'printf "%s\n" "Trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" | add-vmess'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=1)  # You may need to adjust this, as "exp" is not defined in the scope
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)
        msg = f"""

__Accounts Created Suuccessfuly__
**×━━━━━━━━━━━━━━━━━━━━━×**
    Xray/Vmess Accounts
**×━━━━━━━━━━━━━━━━━━━━━×**
🌀Remarks     : {z["ps"]}
🌀Domain      : {z["add"]}
🌀Port TLS    : 8443
🌀Port HTTP   : 8880
🌀User ID     : {z["id"]}
🌀Alter ID    : 0
🌀Security    : auto
🌀Network     : ws
🌀Path        : /v2ray
**×━━━━━━━━━━━━━━━━━━━━━×**
🍀Link TLS  : 
`{b[0].strip("'").replace(" ","")}`
**×━━━━━━━━━━━━━━━━━━━━━×**
🍀Link None TLS : 
`{b[1].strip("'").replace(" ","")}`
**×━━━━━━━━━━━━━━━━━━━━━×**
**✅Format OpenClash✅**
__{z["add"]}:89/vmess-{z["ps"]}.txt__
**📆Expiry      : 1 Days**
        """
        await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await trial_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess-member'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'cek-ws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
╔═╗─╔╗──────────╔═╦═╗
║╔╬═╣╠╗╔═╦═╦══╦═╣═╣═╣
║╚╣╩╣═╣╚╗║╔╣║║║╩╬═╠═║
╚═╩═╩╩╝─╚═╝╚╩╩╩═╩═╩═╝
{z}

**Shows Logged In Users Vmess**
""", buttons=[[Button.inline("‹ Main Menu ›", "vmess-member")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')



## CEK member VMESS
@bot.on(events.CallbackQuery(data=b'cek-member-member'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bash cek-mws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

{z}

**Shows Users from databases**
""", buttons=[[Button.inline("‹ Main Menu ›", "vmess-member")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')





@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | delws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted {user} **"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-vmess-member'))
async def ren_vmess(event):
    async def ren_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Perhatian username pastikan sudah benar.!!**')
            await event.respond('**Username :**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 30 Hari ", "30")]
            ])
            exp = await exp_conv.wait_event(events.CallbackQuery)
            expp = exp.data.decode("ascii")

            await process_user_balance_vmess(event, user_id)

        cmd = f'printf "%s\n" "{user}" "{expp}" | renew-vmess'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Not Found**")
        else:
            msg = f"""**{a}**"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await ren_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

		
@bot.on(events.CallbackQuery(data=b'vmess-member'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline("Create VMess", "create-vmess-member"),
            Button.inline("Renew VMess", "renew-vmess-member")],
            [Button.inline("Trial VMess", "trial-vmess-member")],
            [Button.inline("🔙Kembali", "menu")],
]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**🔰VMESS MENU**
__- VMess None TLS__
__- VMess TLS__
__- Port 8443, 8880__

**🔰SERVER INFO**
__- Domain: {DOMAIN}__
__- Region: {z["country"]}__
``` 💵Harga : Rp6.000/Bulan```
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')



