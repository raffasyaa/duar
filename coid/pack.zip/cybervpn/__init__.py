from telethon import TelegramClient, events
from telethon.tl.functions.users import GetUsersRequest
from telethon.tl import types, functions
from telethon.sync import events
import sqlite3
import logging
import math
import asyncio
import sys
from datetime import datetime

# Logging configuration
logging.basicConfig(level=logging.INFO)

# Bot initialization
BOT_TOKEN = "7758057384:AAEwQwDqMx3lAOIiz6RIDfG8oPwoEHhWqlQ"  # Replace with your actual bot token
bot = TelegramClient("Skarti", "28378594", "b6a05a7ea4e7b15305da7ac0ae698346").start(bot_token=BOT_TOKEN)

# Database helpers
def get_db():
    conn = sqlite3.connect("cybervpn/database.db")
    conn.row_factory = sqlite3.Row
    return conn

# Database initialization
try:
    db = get_db()
    cursor = db.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS server (
            button_name TEXT PRIMARY KEY,
            host TEXT,
            password TEXT
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user (
            user_id INTEGER PRIMARY KEY,
            saldo REAL,
            level TEXT
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS ewallet (
            email TEXT PRIMARY KEY,
            dana TEXT,
            gopay TEXT
        )
    ''')
    db.commit()
except sqlite3.Error as e:
    logging.error(f"Database initialization error: {e}")
finally:
    db.close()

# Helper functions
def register_user(user_id, saldo, level="user"):
    db = get_db()
    try:
        db.execute("INSERT INTO user (user_id, saldo, level) VALUES (?, ?, ?)", (user_id, saldo, level))
        db.commit()
    finally:
        db.close()

def tambah_saldo(user_id, jumlah_tambahan):
    db = get_db()
    try:
        current_saldo = db.execute("SELECT saldo FROM user WHERE user_id=?", (user_id,)).fetchone()
        if current_saldo:
            new_saldo = float(current_saldo[0]) + jumlah_tambahan
            db.execute("UPDATE user SET saldo=? WHERE user_id=?", (new_saldo, user_id))
            db.commit()
    finally:
        db.close()

async def tambah_data_ewallet(email, dana, gopay, event):
    db = get_db()
    try:
        db.execute("INSERT INTO ewallet (email, dana, gopay) VALUES (?, ?, ?)", (email, dana, gopay))
        db.commit()
        await event.respond("Data e-wallet berhasil ditambahkan.")
    except sqlite3.IntegrityError:
        await event.respond("Email sudah ada di database.")
    finally:
        db.close()

async def edit_email_ewallet(old_email, new_email, event):
    db = get_db()
    try:
        cursor = db.execute("UPDATE ewallet SET email=? WHERE email=?", (new_email, old_email))
        db.commit()
        if cursor.rowcount == 0:
            await event.respond("Email lama tidak ditemukan.")
        else:
            await event.respond("Email berhasil diubah.")
    finally:
        db.close()

async def edit_nomor_ewallet(event, email, nomor_baru, field="dana"):
    db = get_db()
    try:
        result = db.execute(f"SELECT {field} FROM ewallet WHERE email=?", (email,)).fetchone()
        if result:
            db.execute(f"UPDATE ewallet SET {field}=? WHERE email=?", (nomor_baru, email))
            db.commit()
            await event.respond(f"Nomor {field} berhasil diubah.")
        else:
            await event.respond("Email tidak ditemukan.")
    finally:
        db.close()

def hapus_user(user_id):
    db = get_db()
    try:
        db.execute("DELETE FROM user WHERE user_id=?", (user_id,))
        db.commit()
    finally:
        db.close()

def tampilkan_semua_user():
    db = get_db()
    try:
        users = db.execute("SELECT * FROM user").fetchall()
        return [
            f"ID: {user['user_id']}, Saldo: {user['saldo']}, Level: {user['level']}" 
            for user in users
        ]
    finally:
        db.close()

def get_saldo_from_db(user_id):
    db = get_db()
    try:
        result = db.execute("SELECT saldo FROM user WHERE user_id=?", (user_id,)).fetchone()
        return result[0] if result else None
    finally:
        db.close()

# Balance processing helpers
async def process_user_balance(event, user_id, cost):
    db = get_db()
    try:
        saldo = get_saldo_from_db(user_id)
        if saldo is None:
            await event.respond("User tidak ditemukan.")
            return
        if saldo >= cost:
            new_saldo = saldo - cost
            db.execute("UPDATE user SET saldo=? WHERE user_id=?", (new_saldo, user_id))
            db.commit()
            await event.respond(f"Saldo berhasil dikurangi. Sisa saldo: {new_saldo}")
        else:
            await event.respond("Saldo tidak mencukupi.")
    finally:
        db.close()

async def process_user_balance_vmess(event, user_id):
    await process_user_balance(event, user_id, cost=6000)

async def process_user_balance_trojan(event, user_id):
    await process_user_balance(event, user_id, cost=5500)
